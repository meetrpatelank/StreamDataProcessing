import java.io.*;
import java.util.StringTokenizer;
public class StockMarket {
	public static void main(String[] args) {
		ReadFile r = new ReadFile();
		System.out.println(r.checkFile());
		System.out.println(r.findRowNumber());
		r.convertToArray();
		r.printArray();
		Formulas f = new Formulas();
		f.createDataArray(r.getArray());
		f.printArray();
		
	}
	
	
}
