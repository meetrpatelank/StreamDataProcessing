import java.io.File;
import java.io.*;
import java.util.StringTokenizer;
public class ReadFile {
	File file = new File("/home/kali/Downloads/stock_test.csv");
	int row = 0;
	String[][] items;
	
	public boolean checkFile() {
		return file.isFile();
	}
	public int findRowNumber() {
		row=0;
		if(checkFile()) {
			//do this if it is a file
			try {
				BufferedReader reader = new BufferedReader(new FileReader(file));
				while(reader.readLine() !=null) {
					row++;
				}
			}
			catch(Exception e) {
				System.out.println(e);
			}
		}
		else
		{
			System.out.println("This is not a file");
		}
		return row;
	}

		public void convertToArray() {
			int r = 0 ;
			items = new String[findRowNumber()][8];
			try {
				BufferedReader reader = new BufferedReader(new FileReader(file));
				String line = null;
				while((line =reader.readLine())!=null) {
					StringTokenizer z = new StringTokenizer(line,",");
					while(z.hasMoreTokens()) {
						for(int c =0; c<8;c++) {
							items[r][c] = z.nextToken();
						}
						r++;
					}
				}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		}
		// prints out ITEMS Array
		public void printArray() {
			for(int x = 0 ; x<items.length;x++) {
				System.out.printf("%s - " ,x);
				for(int y=0;y<items[x].length;y++) {
					System.out.printf("%s ",items[x][y]);
				}
				System.out.println();
			}
		}
		// return Array items
		public String[][] getArray() {
			return items;
		}
}
